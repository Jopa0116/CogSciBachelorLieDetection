function addprompt(){
    /** */
    if(prompts[counter] === '1'){
        addquestion('Truth: ');
    } else {
        addquestion('False: ')
    };
};

function createpromptsequence(){
    /**Function to create randomized sequence of 25 truth prompts and 25 lie prompts to be used in the training scenario */
    var sequence = []
    for(a=1;a < 26;a++){
        sequence.push('1')
    };
    for(b=1;b < 26;b++){
        sequence.push('2')
    };
    for (z = sequence.length - 1; z > 0; z--) {
        y = Math.floor(Math.random() * (z + 1));
        x = sequence[z];
        sequence[z] = sequence[y];
        sequence[y] = x;
    };
    return sequence
};

function keypressTrain(response){
    l('keypressTrain-------1')
    l(keypresscount)
    l('----2')
    l((response.code === 'KeyN' || response.code === 'KeyM') && keypresscount === 0)
    l((response.code === 'KeyN' || response.code === 'KeyM') && keypresscount === 1)
    if((response.code === 'KeyN' || response.code === 'KeyM') && keypresscount === 0) {
        l('keypressTrain-------2'); 
        var readTime = Date.now() - startTime; 
        keypresscount = 1; 
        l(keypresscount)
        IndTruthTime.push(readTime)
        l('------got here -------------')
    } else if((response.code === 'KeyN' || response.code === 'KeyM') && keypresscount == 1){
        l('yooooo')
        if (response.code === 'KeyN') {
            var reactionTime = Date.now() - startTime;
            var qst = "Yes";  
        }
        else if (response.code === 'KeyM') {
            var reactionTime = Date.now() - startTime;
            var qst = "No";
        };

        var ReactionResult = calcCertanty(reactionTime);

        var AgentReactionPrompt = '';
        if(ReactionResult[0] === 'probR'){
            AgentReactionPrompt = 'Please read and consider choices more carfully'
            addquestion(AgentReactionPrompt)
        } else if(ReactionResult[0] === 'probT' || ReactionResult[0] === 'probL'){
            updatecards(qst, ReactionResult, randomQuestions);
        };

        GethighScore(reactionTime)
        if(counter > 1){removeHighscore()};
        uppdateHighscore()

        SaveReactionResult(ReactionResult, reactionTime)
        
        keypresscount = 0

        endkeypressTrain(qst, prompts)
    }else{l('NOTHING')};
};

function updateTrainingPage(Question){
    addprompt();
    addquestion(Question);
    addRedDot();
};

function mainTrain(){

    if(counter == 0) {l('yoyo'); document.addEventListener('keyup', () => {keypressTrain(event)})};
    previusQstn = CurrQstn;
    counter += 1
    l('counter-----')
    l(counter)
    if (counter < 51){
        reactionTime = 0;
        var randkey = selectrandom(Qstns);
        Question = selectrandquestion(randkey);

        // if(counter=== 1){Question = startOver()}else{Question = Strategy1(CurrHgh, CurrQstn)};
        updateTrainingPage(Question);
        startTime = Date.now();
    }
    else {
        var max = 0
        for (var a in cardsBelief) {
            if (max < a){
                console.log('heeeeeeeeeee')
                max = a
            };
        };
        finalprediction(max)
        saveDatatoTEST() //placeholder; Debug Script
        document.removeEventListener('keydown', response)
    }
};

function endkeypressTrain(qst){
    l('endkeypress-----1')
    if (qst === 'Yes' || qst === 'No'){
        l('endkeypress-----2')
        removequestion();
        removequestion();
        hideallRedDots();
        Question = ''
        randomQuestions = ''
        mainTrain()
    };
};
var l = console.log //For faster writing of the command
var testData = {'Participant': ['1'], 'Read_Times': [700, 800, 600], 'Truth_Times': [1000, 1000, 1000], 'Lie_Times': [2000, 2000, 2000]};

function doGetDEBUG(e){
    var yo = new URLSearchParams(e).toString()
    l(yo)
};

function ChangeCardBelief(Card, value){
    /** This code is used to manually change the certanty score of a single card*/
    cardsBelief[Card] = value
};

function saveDatatoTEST(){
    /**This function is a placeholder for the save event */
    nmb = window.localStorage.length + 1
    data = {
        'ReadTimes': IndReadTimes,
        'TruthTime': IndTruthTime,
        'LieTime': IndLieTime
    };
    window.localStorage.setItem('Trail' + toString(nmb), JSON.stringify(data))
}

function loadData(){
    /**This function is a placeholder for the load event */
    if(localStorage.getItem('Trail0') === 'null'){
        var data = [
            [500],
            [1000],
            [1400]
        ];
        window.localStorage.setItem('Trail0', data);
    };

    for(var a in window.localStorage){
        var q = window.localStorage[a]
        l(Object.keys(a))
        l(Object.keys(q))
        for(b = 0; b <= 50; b++){
            testReadTime.push(a['ReadTimes'][b]);
            testTruthTime.push(a['TruthTime'][b]);
            testLieTime.push(a['LieTime'][b]);
        };
    };
};



/** LOBOTOMIZED FUNCTIONS BELLOW */
/*function timekeypress(){
    document.addEventListener('keydown', (response) => {
        l('problem')
        var reactionTime = Date.now() - startTime;
        IndReadTimes.push(reactionTime)
        document.removeEventListener('keydown', response)
        keypressTrain(prompts)
    });
};*/

/**l(document.getElementById("SVG_tree").firstElementChild)
    document.getElementById("SVG_tree").getSVGDocument().getElementsByClassName('cls-9').visibility = "hidden" */

function removeRedDot(){
    document.getElementById(CurrQstn).visibility = "hidden"
};

function getTop5Debug(){
    var top5 = {}
    var max = 'AceD';
    var previus = {'AceD':1}
    console.log(previus['AceD'] !== 1)
};

function drawTree(){
    drawSVG('Tree.svg', 'SVG_Tree');
    document.getElementById('SVG_Tree');
    changeSize('SVG_Tree', '25%', '40%');
    changePosition('SVG_Tree', '36%', '66%')
};


function drawSVG(SVG, location){
    var pic = document.createElement('object');
    pic.id = 'SVG_tree'
    pic.data = SVG;
    pic.type = 'image/svg+xml'
    pic.style.position = 'absolute';
    pic.style.backgroundSize = 'cover';
    var place = document.getElementById(location);
    place.appendChild(pic);
};


/*function keypressTrain(prompts){
    document.addEventListener('keydown', (response) => {
        
        
        l('Hello')
        var keypresscount = 0
        if(response == true && keypresscount != true){
            l('yoo')
            var reactionTime = Date.now() - startTime;
            keypresscount = 1
            IndTruthTime.push(reactionTime);
        }
        else if(response.code === 'KeyN' || response.code === 'KeyM' && keypresscount > 1){
            l('mooooooo')
            if (response.code === 'KeyN') {
                l('nnnnnnnnnnnnnn')
                var reactionTime = Date.now() - startTime;
                var answ = "Yes";
                IndTruthTime.push(reactionTime)
            }
            else if (response.code === 'KeyM') {
                l('mmmmmmmmmmmmmmm')
                var reactionTime = Date.now() - startTime;
                var answ = "No";
                IndLieTime.push(reactionTime)
            };

            var ReactionResult = calcCertanty(reactionTime)

            l(ReactionResult)
            updatecards(answ, ReactionResult, CurrQstn);

            GethighScore(reactionTime);
            if(document.getElementById('Highscore').firstChild == true){removeHighscore()};
            //removeHighscore();
            uppdateHighscore();

            SaveReactionResult(ReactionResult, reactionTime)

            var keypresscount = 0
            endkeypressTrain(answ, prompts)
        } else {return}
    });
};*/

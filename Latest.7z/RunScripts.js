// doGetDEBUG(testData)
// submit(testData);

hideElement('Exjobb_Web'); //Graphics.js
hideallRedDots()
document.addEventListener('keyup', MAIN) //GeneralScript.js
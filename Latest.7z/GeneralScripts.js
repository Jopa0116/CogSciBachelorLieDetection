function selectrandquestion(randkey){
    var questions = questionDict[randkey];
    randomQuestions = questions[Math.floor(Math.random() * questions.length)];
    if(randomQuestions != 'undefined') {
        setCurrentQstn(randomQuestions)
        var Question = document.getElementById(randomQuestions).value
        return Question
    } else {
        questions = questionDict[randkey];
        randomQuestions = questions[Math.floor(Math.random() * questions.length)];
    };
};

function setCurrentQstn(QstnID) {
    CurrQstn = QstnID;
};

function getHighestProbCard(){
    var max = 0;
    for (var a in cardsBelief) {
        var value = cardsBelief[a]
        if (max < value){
            max = a
        };
    };
    return max
};

function getTop5(){
    var top5 = {}
    var temp = cardsBelief;
    max = '';
    previus = {}
    for(x = 0; x <= 4; x++){
        for (var a in cardsBelief) {
            if (cardsBelief[max] < cardsBelief[a] && previus[a] !== 1){
                max = a;
            };
        };
        previus[max] = 1
        top5[max] = cardsBelief[max];
        max = ''
    };
    return top5
};

function getCards(question){
    var cards = questionCard[question];
    return cards;
};

function finalprediction(highestcard){
    addquestion(highestcard); //placeholder
};

function SaveData(){
    nmb = loadedData.lenght + 1 //Need to create loaded data
    var Data = {
        'Participant': 'Participant'.concat(toString(nmb)),
        'Read_Times' : IndReadTimes, 
        'Truth_Times' : IndTruthTime,
        'Lie_Times' : IndLieTime,
        'StrategySqnc': StrategySqnc, //need to create this
        'StrategyReward': StrategySqnc
    };
    submit(Data)
};

function GethighScore(reactionTime){
    highScore = highScore + (20000 - reactionTime);
};

function removeHighscore(){
    var place = document.getElementById("Highscore");
    var trash = place.firstChild
    place.removeChild(trash)
};

function SaveReactionResult(ReaktionResult, reactionTime){
    if (ReaktionResult === true){
        IndTruthTime.push(reactionTime)
    } else {
        IndLieTime.push(reactionTime)
    };
};

function updatecards(answer, ReactionResult, question){
    var cards = getCards(question)
    var multipleCards = Array.isArray(cards)
    if (answer === 'Yes'){
        if (ReactionResult[0] === 'probT'){
            if(multipleCards === true){
                for(a=0; a <= cards.length; a++){
                    cardsBelief[cards[a]] = cardsBelief[cards[a]] + ReactionResult[1]
                };
            } else {
                cardsBelief[cards[a]] = cardsBelief[cards[a]] + ReactionResult[1]
            };
        } else if (ReactionResult[0] === 'probL'){
            if(multipleCards === true){
                for(a=0; a <= cards.length; a++){
                    cardsBelief[cards[a]] = cardsBelief[cards[a]] - ReactionResult[1]
                };
            } else {
                cardsBelief[cards[a]] = cardsBelief[cards[a]] - ReactionResult[1]
            };
        };
    } else if (answer === 'No'){
        if (ReactionResult[0] === 'probT'){
            if(multipleCards === true){
                for(a=0; a <= cards.length; a++){
                    cardsBelief[cards[a]] = cardsBelief[cards[a]] - ReactionResult[1]
                };
            } else {
                cardsBelief[cards[a]] = cardsBelief[cards[a]] - ReactionResult[1]
            };
        } else if (ReactionResult[0] === 'probL'){
            if(multipleCards === true){
                for(a=0; a <= cards.length; a++){
                    cardsBelief[cards[a]] = cardsBelief[cards[a]] + ReactionResult[1]
                };
            } else {
                cardsBelief[cards[a]] = cardsBelief[cards[a]] + ReactionResult[1]
            };
        };
    };
};

function uppdateHighscore(){
    var place = document.getElementById("Highscore");
    var d = document.createElement('text');
    d.innerHTML = highScore
    place.append(d)
};

function coinflip(){
    return 0 //Debug line
    // return Math.round(Math.random())
};

function MAIN(press){
    l('MAIN----')
    if(press.code === 'KeyN' && keypresscount === 0){
        hideElement('IntroductionP1');
        hideElement('IntroductionP2');
        var flip = coinflip();
        if(flip === 1){
            var scenario = document.getElementById('shwn_tst');
            scenario.innerHTML = 'You will begin with the test scenario';
            beganwith = 'Test'; 
        }else{ 
            var scenario = document.getElementById('shwn_trng');
            scenario.innerHTML = 'You will begin with the training scenario';
            beganwith = 'Training'
        };
        keypresscount = 1
    } else if(press.code === 'KeyN' && keypresscount === 1){
        hideElement('Scenario');
        var elmnt = document.createElement('h1')
        elmnt.innerHTML = questionCard[ParticipantsDraw]
        document.getElementById('drawn_card').appendChild(elmnt)
        keypresscount = 2
    } else if (press.code === 'KeyN' && keypresscount === 2 && beganwith === 'Training'){
        hideElement('drawn_card'); //Graphics.js
        // l('Training')
        document.removeEventListener('keyup', MAIN, false);
        showElement('Exjobb_Web');
        keypresscount = 0;
        l(keypresscount)
        l('----1')
        l(keypresscount)
        // document.addEventListener('keyup', keypressTrain(event)); //Training.js
        mainTrain(); //Training.js
    } else if (press.code === 'KeyN' && keypresscount === 2 && beganwith === 'Test'){
        keypresscount = 0;
        l('TEST');
    } else {l('NOOOO')}
};

function UpdateDot(){
    
};
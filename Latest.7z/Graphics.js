function addquestion(Question){
    var place = document.getElementById("Questions_here");
    var q = document.createTextNode(Question);
    place.appendChild(q);
};

function addRedDot(){
    if(CurrQstn[0] + CurrQstn[1] == 'Q2'){
        l('addRED--------1')
        l(document.getElementById(CurrQstn).parentElement.id == ('Q3_1' || 'Q3_2' || 'Q3_3'|| 'Q3_4'))
        if(document.getElementById(CurrQstn).parentElement.id == 'Q3_1') {var b = 'Red_' + CurrQstn + 'a'};
        if(document.getElementById(CurrQstn).parentElement.id == 'Q3_2') {var b = 'Red_' + CurrQstn + 'b'};
        if(document.getElementById(CurrQstn).parentElement.id == 'Q3_3') {var b = 'Red_' + CurrQstn + 'c'};
        if(document.getElementById(CurrQstn).parentElement.id == 'Q3_4') {var b = 'Red_' + CurrQstn + 'd'};
    } else if (CurrQstn[0] + CurrQstn[1] == ('Q1' || 'Q3')) {
        var b = 'Red_' + CurrQstn;
    } else {var b = 'Red_rect'};
    $('#' + b).attr('visibility', 'visible');
};

function changePosition(element, Bottom, Right){
    var elm = document.getElementById(element).firstChild;
    elm.style.bottom = Bottom;
    elm.style.right = Right;
};

function changeSize(element, Width, Hight){
    var elm = document.getElementById(element).firstChild;
    elm.style.width = Width;
    elm.style.height = Hight;
};

function hideallRedDots(){
    // l('hide--------')
    // l(document.getElementsByClassName('cls-9'))
    $('.cls-9').attr('visibility', 'hidden');
};

function hideElement(elementID){
    var game = document.getElementById(elementID);
    game.style.display = 'none'
};

function removequestion(){
    var place = document.getElementById("Questions_here");
    var trash = place.firstChild
    while(trash){
        place.removeChild(trash)
        trash = place.firstChild
    };
};


function showElement(elementID){
    var game = document.getElementById(elementID);
    game.style.display = 'initial'
};
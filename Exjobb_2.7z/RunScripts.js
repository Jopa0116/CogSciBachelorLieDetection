drawTree(); //Graphics.js
// loadData();
prompts = createpromptsequence(); //Training.js
addquestion(ParticipantsDraw); //Graphics.sj
//document.addEventListener()
keypressTrain(prompts); //Training.js
mainTrain(prompts); //Training.js
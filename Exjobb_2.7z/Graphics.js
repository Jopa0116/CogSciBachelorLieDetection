function drawSVG(SVG, location){
    var pic = document.createElement('img');
    pic.src = SVG;
    pic.style.position = 'absolute';
    pic.style.backgroundSize = 'cover';
    var place = document.getElementById(location);
    place.appendChild(pic);
};

function drawTree(){
    drawSVG('Tree.svg', 'SVG_Tree');
    document.getElementById('SVG_Tree');
    changeSize('SVG_Tree', '25%', '40%');
    changePosition('SVG_Tree', '36%', '66%')
};

function addquestion(Question){
    var place = document.getElementById("Questions_here");
    var q = document.createTextNode(Question);
    CurrQstn = Question;
    place.appendChild(q);
};

function removequestion(){
    var place = document.getElementById("Questions_here");
    var trash = place.firstChild
    while(trash){
        place.removeChild(trash)
        trash = place.firstChild
    };
};

function changeSize(element, Width, Hight){
    var elm = document.getElementById(element).firstChild;
    elm.style.width = Width;
    elm.style.height = Hight;
};

function changePosition(element, Bottom, Right){
    var elm = document.getElementById(element).firstChild;
    elm.style.bottom = Bottom;
    elm.style.right = Right;
};
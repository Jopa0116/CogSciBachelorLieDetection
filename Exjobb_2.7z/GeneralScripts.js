function selectrandquestion(randkey, questionDict){
    var questions = questionDict[randkey];
    randomQuestions = questions[Math.floor(Math.random() * questions.length)];
    var Question = document.getElementById(randomQuestions).value
    CurrQstn = Question
    return Question
};

function getHighestProbCard(){
    var max = 0;
    for (var a in cardsBelief) {
        var value = cardsBelief[a]
        if (max < value){
            max = a
        };
    };
    return max
};

function getTop5(){
    var top5 = {}
    var temp = cardsBelief;
    max = '';
    previus = {}
    for(x = 0; x <= 4; x++){
        for (var a in cardsBelief) {
            if (cardsBelief[max] < cardsBelief[a] && previus[a] !== 1){
                max = a;
            };
        };
        previus[max] = 1
        top5[max] = cardsBelief[max];
        max = ''
    };
    return top5
};

function getCards(question){
    var cards = questionCard[question];
    return cards;
};

function finalprediction(highestcard){
    addquestion(highestcard); //placeholder
};

function SaveData(){
    nmb = loadedData.lenght + 1 //Need to create loaded data
    var Data = {
        'Participant': 'Participant'.concat(toString(nmb)),
        'Read_Times' : IndReadTimes, 
        'Truth_Times' : IndTruthTime,
        'Lie_Times' : IndLieTime,
        'StrategySqnc': StrategySqnc, //need to create this
        'StrategyReward': StrategySqnc
    };
    submit(Data)
};

function GethighScore(reactionTime){
    highScore = highScore + (20000 - reactionTime);
};

function removeHighscore(){
    var place = document.getElementById("Highscore");
    var trash = place.firstChild
    place.removeChild(trash)
};

function SaveReactionResult(ReaktionResult, reactionTime){
    if (ReaktionResult === true){
        IndTruthTime.push(reactionTime)
    } else {
        IndLieTime.push(reactionTime)
    };
};

function updatecards(answer, ReactionResult, question){
    var cards = getCards(question)
    var multipleCards = Array.isArray(cards)
    if (answer === 'Yes'){
        if (ReactionResult[0] === 'probT'){
            if(multipleCards === true){
                for(a=0; a <= cards.length; a++){
                    cardsBelief[cards[a]] = cardsBelief[cards[a]] + ReactionResult[1]
                };
            } else {
                cardsBelief[cards[a]] = cardsBelief[cards[a]] + ReactionResult[1]
            };
        } else if (ReactionResult[0] === 'probL'){
            if(multipleCards === true){
                for(a=0; a <= cards.length; a++){
                    cardsBelief[cards[a]] = cardsBelief[cards[a]] - ReactionResult[1]
                };
            } else {
                cardsBelief[cards[a]] = cardsBelief[cards[a]] - ReactionResult[1]
            };
        };
    } else if (answer === 'No'){
        if (ReactionResult[0] === 'probT'){
            if(multipleCards === true){
                for(a=0; a <= cards.length; a++){
                    cardsBelief[cards[a]] = cardsBelief[cards[a]] - ReactionResult[1]
                };
            } else {
                cardsBelief[cards[a]] = cardsBelief[cards[a]] - ReactionResult[1]
            };
        } else if (ReactionResult[0] === 'probL'){
            if(multipleCards === true){
                for(a=0; a <= cards.length; a++){
                    cardsBelief[cards[a]] = cardsBelief[cards[a]] + ReactionResult[1]
                };
            } else {
                cardsBelief[cards[a]] = cardsBelief[cards[a]] + ReactionResult[1]
            };
        };
    };
};

function uppdateHighscore(){
    var place = document.getElementById("Highscore");
    var d = document.createElement('text');
    d.innerHTML = highScore
    place.append(d)
};
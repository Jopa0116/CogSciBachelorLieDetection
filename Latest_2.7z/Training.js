var prompts = createpromptsequence();

function addprompt(){
    /** */
    if(prompts[counter] === '1'){
        addquestion('Truth: ');
    } else {
        addquestion('False: ')
    };
};

function createpromptsequence(){
    /**Function to create randomized sequence of 25 truth prompts and 25 lie prompts to be used in the training scenario */
    var sequence = []
    for(a=1;a < 26;a++){
        sequence.push('1')
    };
    for(b=1;b < 26;b++){
        sequence.push('2')
    };
    for (z = sequence.length - 1; z > 0; z--) {
        y = Math.floor(Math.random() * (z + 1));
        x = sequence[z];
        sequence[z] = sequence[y];
        sequence[y] = x;
    };
    return sequence
};

function keypressreadQSTN() {
    if(response.code === 'KeyN' || response.code === 'KeyM') {
        // l('keypressTrain-------2'); 
        var readTime = Date.now() - startTime; 
        keypresscount = 1; 
        // l(keypresscount)
        Training_read.push(readTime)
        // l('------got here -------------')
    };
};

function keypressTrain(response){
    // l('keypressTrain-------1')
    // l(keypresscount)
    // l('----2')
    // l((response.code === 'KeyN' || response.code === 'KeyM') && keypresscount === 0)
    // l((response.code === 'KeyN' || response.code === 'KeyM') && keypresscount === 1)
    // l(response)
    if(response.code === 'KeyN' || response.code === 'KeyM'){
        // l('yooooo')
        if (response.code === 'KeyN') {
            var reactionTime = Date.now() - startTime;
            var qst = "Yes";  
        }
        else if (response.code === 'KeyM') {
            var reactionTime = Date.now() - startTime;
            var qst = "No";
        };

        // l(reactionTime)
        var ReactionResult = calcCertanty(reactionTime);
        // l(ReactionResult)

        var AgentReactionPrompt = '';
        if(ReactionResult[0] === 'probR'){
            l('ReadTIme')
            AgentReactionPrompt = 'Please read and consider choices more carfully'
            addquestion(AgentReactionPrompt)
        } else if(ReactionResult[0] === 'probT' || ReactionResult[0] === 'probL'){
            updatecards(qst, ReactionResult, CurrQstn);
        };

        GethighScore(reactionTime)
        if(counter > 1){removeHighscore()};
        uppdateHighscore()

        SaveReactionResultTraining(ReactionResult, reactionTime)
        
        keypresscount = 0

        Training_answers.push(qst)
        endkeypressTrain(qst, prompts)
    }else{l('NOTHING')};
};

function updateTrainingPage(Question){
    addprompt();
    addquestion(Question);
    addRedDot();
};

function mainTrain(){
    l('ööööööööööööööööööööööööööööööööööööööööööööööööööööööö')
    // l('mainTrain1')
    // l(CurrQstn)
    // if(counter == 0) {document.addEventListener('keyup', keypressTrain)};
    if(counter == 0){setTimeout(()=>{document.addEventListener('keyup', keypressTrain)}, 700)} // This was needeed to prevent a bug, unlikley reeaction time anyhow 
    previusQstn = CurrQstn;
    counter += 1
    if (counter < 53){
        reactionTime = 0;
        QstnKey = Strategy1(CurrHgh, CurrQstn);
        // l('mainTrain2')
        // l(QstnKey)
        Question = document.getElementById(QstnKey).innerHTML
        updateTrainingPage(Question);
        startTime = Date.now();
        // l('mainTrain3')
        // l(CurrQstn)
    }
    else {
        l('NOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOONONONONONO')
        // document.removeEventListener('keyup', keypressTrain())
        document.removeEventListener('keyup', keypressTrain)
        var max = -10
        var selection = ''
        for (var a in cardsBelief) {
            // l(cardsBelief)
            if (max < a){
                console.log('heeeeeeeeeee')
                max = cardsBelief[a]
                selection = a
            };
        };
        finalprediction(CurrHgh)
        Training_HS.push(highScore)
        data = gatherData()
        submit(data) //placeholder; Debug Script
    }
};

function endkeypressTrain(qst){
    // l('endkeypress-----1')
    if (qst === 'Yes' || qst === 'No'){
        // l('endkeypress-----2')
        removequestion();
        removequestion();
        hideallRedDots();
        Question = ''
        randomQuestions = ''
        l('++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
        mainTrain()
    };
};
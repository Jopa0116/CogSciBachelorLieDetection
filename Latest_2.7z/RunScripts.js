// doGetDEBUG(testData)
// submit(testData);

hideElement('Exjobb_Web'); //Graphics.js
hideallRedDots()
MAIN() //GeneralScript.js
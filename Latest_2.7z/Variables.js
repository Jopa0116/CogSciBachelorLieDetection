// if(localStorage.getItem('testReadTime')!=true){localStorage.setItem('testReadTime', [500])};
// if(localStorage.getItem('testTruthTime')!=true){localStorage.setItem('testTruthTime', [1000])};
// if(localStorage.getItem('testLieTime')!=true){localStorage.setItem('testLieTime', [1400])};

var testReadTime = [532, 423, 1023, 976]//localStorage.getItem('testReadTime')//[0532, 0423, 1023, 0976];
var testTruthTime = [1000, 1243, 1212, 1111]//localStorage.getItem('testTruthTime')//[1000, 1243, 1212, 1111];
var testLieTime = [2211, 2345, 2432, 2255]//localStorage.getItem('testLieTime')//[2211, 2345, 2432, 2255];
// if (window.localStorage.length !== 5){
    // window.localStorage.setItem('ReadTime', testReadTime);
    // window.localStorage.setItem('TruthTime', testTruthTime);
    // window.localStorage.setItem('LieTime', testLieTime);
    // window.localStorage.setItem('IndLieTime', []);
    // window.localStorage.setItem('IndTruthTime', []);
// };
// The above is a placholder

var cardsBelief = {
    '' : -1000,
    'AceD': 0,
    'D2': 0,
    'D3': 0,
    'D4': 0,
    'D5': 0,
    'D6': 0,
    'D7': 0,
    'D8': 0,
    'D9': 0,
    'D10': 0,
    'JackD': 0,
    'QueenD': 0,
    'KingD': 0,
    'AceH': 0,
    'H2': 0,
    'H3': 0,
    'H4': 0,
    'H5': 0,
    'H6': 0,
    'H7': 0,
    'H8': 0,
    'H9': 0,
    'H10': 0,
    'JackH': 0,
    'QueenH': 0,
    'KingH': 0,
    'AceS': 0,
    'S2': 0,
    'S3': 0,
    'S4': 0,
    'S5': 0,
    'S6': 0,
    'S7': 0,
    'S8': 0,
    'S9': 0,
    'S10': 0,
    'JackS': 0,
    'QueenS': 0,
    'KingS': 0,
    'AceC': 0,
    'C2': 0,
    'C3': 0,
    'C4': 0,
    'C5': 0,
    'C6': 0,
    'C7': 0,
    'C8': 0,
    'C9': 0,
    'C10': 0,
    'JackC': 0,
    'QueenC': 0,
    'KingC': 0,
};

var testRTM = calcMean(testReadTime)
var testRTstd = calcSTD(testReadTime, testRTM)
var testTTM = calcMean(testTruthTime)
var testTTstd = calcSTD(testTruthTime, testTTM)
var testLTM = calcMean(testLieTime)
var testLTstd = calcSTD(testLieTime, testLTM)

var IndReadTimes = [];
var IndTruthTime = [];
var IndLieTime = [];

var highScore = 0;
var reactionTime = 0;
var startTime = 0;
var counter = 0;

var previusQstn = ''; 
var CurrQstn = '';
var CurrHgh = '';
var keypresscount = 0

var beganwith = ''                                      //Defined in the MAIN() function in the Main.js file

// var dotplace = ''
function addprompt(prompts){
    if(prompts[counter] === '1'){
        addquestion('Truth: ');
    } else {
        addquestion('False: ')
    };
};

function createpromptsequence(){
    var sequence = []
    for(a=1;a < 26;a++){
        sequence.push('1')
    };
    for(b=1;b < 26;b++){
        sequence.push('2')
    };
    for (z = sequence.length - 1; z > 0; z--) {
        y = Math.floor(Math.random() * (z + 1));
        x = sequence[z];
        sequence[z] = sequence[y];
        sequence[y] = x;
    };
    return sequence
};

function keypressTrain(prompts){
    document.addEventListener('keydown', (response) => {
        
        
        l('Hello')
        var keypresscount = 0
        if(response == true && keypresscount != true){
            l('yoo')
            var reactionTime = Date.now() - startTime;
            keypresscount = 1
            IndTruthTime.push(reactionTime);
        }
        else if(response.code === 'KeyN' || response.code === 'KeyM' && keypresscount > 1){
            l('mooooooo')
            if (response.code === 'KeyN') {
                l('nnnnnnnnnnnnnn')
                var reactionTime = Date.now() - startTime;
                var answ = "Yes";
                IndTruthTime.push(reactionTime)
            }
            else if (response.code === 'KeyM') {
                l('mmmmmmmmmmmmmmm')
                var reactionTime = Date.now() - startTime;
                var answ = "No";
                IndLieTime.push(reactionTime)
            };

            var ReactionResult = calcCertanty(reactionTime)

            l(ReactionResult)
            updatecards(answ, ReactionResult, CurrQstn);

            GethighScore(reactionTime);
            if(document.getElementById('Highscore').firstChild == true){removeHighscore()};
            //removeHighscore();
            uppdateHighscore();

            SaveReactionResult(ReactionResult, reactionTime)

            var keypresscount = 0
            endkeypressTrain(answ, prompts)
        } else {return}
    });
};

function mainTrain(prompts){
    counter += 1
    if (counter < 51){
        reactionTime = 0
        var randkey = selectrandom(Qstns);
        Question = selectrandquestion(randkey, questionDict);
        //if(counter=== 1){Question = startOver()}else{Question = Strategy1(CurrHgh, CurrQstn)};
        addprompt(prompts)
        addquestion(Question);
        startTime = Date.now();
    }
    else {
        var max = 0
        for (var a in cardsBelief) {
            if (max < a){
                console.log('heeeeeeeeeee')
                max = a
            };
        };
        finalprediction(max)
        saveDatatoTEST() //placeholder; Debug Script
    }
};

function endkeypressTrain(qst, prompts){
    if (qst === 'Yes' || qst === 'No'){
        removequestion()
        removequestion()
        Question = ''
        randomQuestions = ''
        mainTrain(prompts)
    };
};
const URLsheet = 'https://script.google.com/macros/s/AKfycbxLqEjhQIMZzwrGdYmouQXmfWDcMSASIG0RFx7mTB6LYQrpPL4/exec'

/**
 * Stores data in the spreadsheet that is specified in the URL above.
 * @param {object} data JSON object whose keys correspond to column headers in the spreadsheet
 * 
 * Example function call:
 * ``submit({ age: 42, gender: 'male', education: 'bachelor' })``
 * 
 */
function submit(data) {
    const url = `${URL}?${new URLSearchParams(data).toString()}`
    console.log(url)
    fetch(url,
    { method: 'GET' })
    .then( result => console.log(result) )
}

var l = console.log //For faster writing of the command

function ChangeCardBelief(Card, value){
    /** This code is used to manually change the certanty score of a single card*/
    cardsBelief[Card] = value
};

function saveDatatoTEST(){
    /**This function is a placeholder for the save event */
    nmb = window.localStorage.length + 1
    data = {
        'ReadTimes': IndReadTimes,
        'TruthTime': IndTruthTime,
        'LieTime': IndLieTime
    };
    window.localStorage.setItem('Trail' + toString(nmb), JSON.stringify(data))
}

function loadData(){
    /**This function is a placeholder for the load event */
    if(localStorage.getItem('Trail0') === 'null'){
        var data = [
            [500],
            [1000],
            [1400]
        ];
        window.localStorage.setItem('Trail0', data);
    };

    for(var a in window.localStorage){
        var q = window.localStorage[a]
        l(Object.keys(a))
        l(Object.keys(q))
        for(b = 0; b <= 50; b++){
            testReadTime.push(a['ReadTimes'][b]);
            testTruthTime.push(a['TruthTime'][b]);
            testLieTime.push(a['LieTime'][b]);
        };
    };
};



/** LOBOTOMIZED FUNCTIONS BELLOW */
/*function timekeypress(){
    document.addEventListener('keydown', (response) => {
        l('problem')
        var reactionTime = Date.now() - startTime;
        IndReadTimes.push(reactionTime)
        document.removeEventListener('keydown', response)
        keypressTrain(prompts)
    });
};*/

function getTop5Debug(){
    var top5 = {}
    var max = 'AceD';
    var previus = {'AceD':1}
    console.log(previus['AceD'] !== 1)
};
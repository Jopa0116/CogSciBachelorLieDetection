var strategy = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];

function getdiffIndvMean(dataSetL, dataSetT){
    /**Calulates the mean difference between  lying and telling the truth*/
    var truth = calcMean(dataSetT)
    var lie = calcMean(dataSetL)
    return (lie - truth)
}; 

function stretegiesreward(diffIndvMeanNew, diffIndvMeanOld){
    /**Reard system for  individual mean difference. It provides proper feedback by checking what the diff is 
     * between the new and the old data. Providing possitive feedback for incresing difference between
     * old and new difference. The system should converge when there is a difference of 2000ms.
     * 
     * The function takes two parameters which are the current diff in mean (diffIndvMeanNew) 
     * and the old (diffIndvMeanOld). It returns either a negative or possitive reward.
    */
    rewardStep1 = diffIndvMeanNew - diffIndvMeanOld;
    if (rewardStep1 < 0){
        return negativeReward = (-1 * pow(rewardStep1, 2)); 
    }else if (rewardStep1 > 1 && diffIndvMeanOld < 2000) {
        return positiveReward = pow(rewardStep1, 2);
    };
};

function shouldDecend(question, highestCard){
    /** A function to answer the question if the software agent should decend in the search tree.
     * It takes two parameater which are the question it is currently asking (question). Which represents the 
     * agents current state. And the card of highest certanty (highestCard) which represents its goal.
     * 
     * The algorith check upwards from the goal too see if it finds the current state. If not it is assumed 
     * that the agent should ascend instead of deceand to get to the path of the goal. If it is at the lowest 
     * level of the tree it returns 
     */
    goal = document.getElementById(highestCard); // Gets element of highest card from id: 'TreeStructure' in the html
    var current = goal; //It to search from its goal
    var ascended = [current]; //Array of places visited
    l(highestCard)
    if(question[1] != 4 || question[1] != 5 || question[1] != 6 || question[1] != 7){
        l('heeeeeeeereeeeee')
        for(var a = 4; a > parseInt(question[1]); a--){
            l(current.parentNode)
            current = current.parentNode
            ascended.push(current)
            if(current.value === question){
                return ascended[a-1].value //The next question (state)
            }else if(ascended.length === a && ascended[a].value != question){
                return false
            };
        };
    }else{return 'lowest'};
};

function Ascend(question){
    /**A function for determining which is the next question by ascending in the search tree. It takes the current
     * question as a parameater and return what its next state should be 
    */
    var tree = document.getElementsByClassName('Tree')
    for(var a in tree){
        if(a.value === question){
            var nextState = a.parentNode.value
        };
    };
    return nextState
};

function startOver(){
    beginwith = Math.round(Math.random())
    if(beginwith === 0){
        var nextState = 'Q1_1'
    } else {
        var nextState = 'Q1_2'
    };
    return nextState
};

function Testtop(){
    top5 = getTop5();
    selection = Math.floor(Math.random * top5.length)
    var nextState = top5[selection]
    return nextState
};

function Strategy1(highestCard, question){
    answer = shouldDecend(question, highestCard);
    if(answer === false){
        var nextState = Ascend(question) 
    } else if (answer === 'lowest'){
        if(counter < 31){
            nextState = startOver()
        } else {
            nextState = Testtop()
        };
    } else {
        var nextState = answer
    };
    return nextState
};

function selectrandom(Qstns){
    var randkey = Qstns[Math.floor(Math.random() * Qstns.length)];
    return randkey
};

function horizontalSample(question){
    var Name = document.getElementById(question).name
    qstns = document.getElementsByName(Name)
    var nmb = Math.floor(Math.random(qstns.length))
}; //Note to self: Finish!

